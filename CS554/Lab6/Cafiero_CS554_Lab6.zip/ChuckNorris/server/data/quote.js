const Quotes = [
  { id: "454dccf0-9ebc-457b-b9d1-313255a7ddea", quote: "When Chuck Norris was born he drove his mom home from the hospital." },
  { id: "ac2b5539-b036-4aeb-9e62-ace5a95942ab", quote: "Chuck Norris has a diary. It's called the Guinness Book of World Records." },
  { id: "ab648889-f53a-4fdd-9e22-511bcfe45dcc", quote: "Chuck Norris threw a grenade and killed 50 people, then it exploded." },
  { id: "a6cf34b9-c317-450b-bfc0-346599df21a1", quote: "Chuck Norris counted to infinity. Twice." },
  { id: "5a1c7249-c3f4-4321-8b44-4f49707a1c9c", quote: "Chuck Norris beat the sun in a staring contest." }
];

module.exports = Quotes;