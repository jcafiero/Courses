# Installation
Install the dependencies using:

``` 
npm install
```

To start the GraphQL server, run it using `node server.js` or `nodemon server.js` in the root directory of your application.