Jennifer Cafiero
CS546 Lab 2
Modules and Basic Node

To run lab, open the Terminal. Change directories to the lab files' location. Type 'npm start' and the results of index.js will print on the screen.
