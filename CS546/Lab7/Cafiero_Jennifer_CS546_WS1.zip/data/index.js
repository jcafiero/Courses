/********
 * Name: Jennifer Cafiero
 * Date: October 25, 2017
 * CS546 Lab 7 - A Recipe API
 * index.js
 * Pledge: I pledge my honor that I have abided by the Stevens Honor System
 ********/

module.exports = {
  recipes: require("./recipes")
};
