Jennifer Cafiero
CS546 Lab 3
Asynchronous Code, Files, and Promises

I tried getting the async working but it was giving me a lot of problems and I had a stressful weekend so I couldn't get extra help - Sorry!
