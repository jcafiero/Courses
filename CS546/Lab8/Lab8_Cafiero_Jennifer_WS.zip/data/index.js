/********
 * Name: Jennifer Cafiero
 * Date: November 9, 2017
 * CS546 Lab 8 - Palindromes
 * index.js
 * Pledge: I pledge my honor that I have abided by the Stevens Honor System
 ********/

let constructorMethod = (app) => {
    app.use("/", termData);
};
module.exports = {
    terms: termData
};
